public enum ColorCar {
    BLACK,
    WHITE,
    RED
}

public class Fabrica {
    public String name;

    public String getName() {
        return name;
    }

    public Fabrica(String name) {
        this.name = name;
    }

}

public class Main {
    public static void main(String[] args) {
        Fabrica fabrica = new Fabrica("Mercedes X");
Mercedes mercedes = new Mercedes(2.5, 2010, ColorCar.BLACK, fabrica);
        System.out.println(mercedes.getInfo());





    }

}